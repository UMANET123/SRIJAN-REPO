exports.get = function(req, res){
    res.render('demo/demo');
}